# -*- coding: utf-8 -*-
import csv
import datetime
import os
import sys
import re
import time
from copy import deepcopy

import scrapy


class ReviewDetailSpider(scrapy.Spider):
    name = 'review_detail'
    # name = 'review'
    allowed_domains = ['www.amazon.com',  # 美国站点
                       'www.amazon.co.uk',  # 英国站点
                       'www.amazon.fr',  # 法国站点
                       'www.amazon.de',  # 德国站点
                       'www.amazon.it',  # 意大利站点
                       'www.amazon.com.mx',  # 墨西哥站点
                       'www.amazon.ca',  # 加拿大站点
                       'www.amazon.com.au',  # 澳大利亚站点
                       'www.amazon.es',  # 西班牙站点
                       ]

    def __init__(self, asin=None, site=None, *args, **kwargs):
        super(ReviewDetailSpider, self).__init__(*args, **kwargs)
        self.site = site
        self.asin = asin
        print(self.site)
        print(self.asin)
        self.start_urls = [self.site]
        print(os.path.dirname(sys.path[0]))

        self.file = './asin_list.csv'  # 打包后的路径是EXE文件路径为参考线
        self.review_homepage_url = self.site + '/product-reviews/{}'
        self.review_base_url = self.site + '/product-reviews/{}/ref=cm_cr_arp_d_paging_btm_next_{}?ie=UTF8&reviewerType=all_reviews&sortBy=recent&pageNumber={}'

    def read_file(self, File):
        """ 读取文件中ASIN """
        if File.endswith('.csv'):
            with open(File, 'r') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    # 读取ASIN字段数据
                    column = row['ASIN']
                    if column != "None":
                        yield column
                    else:
                        pass

    def parse(self, response):
        """ 判断asin是否为空，如果是空的就读取asin_list.csv中的ASIN并遍历请求每一个asin的评论页面，否则请求当前的asin的评论网页 """
        if self.asin:
            asin = self.asin
            url = self.review_homepage_url.format(asin)
            print(url)
            yield scrapy.Request(url, callback=self.page_count, meta={'asin': deepcopy(asin)})
        else:
            try:
                for asin in self.read_file(self.file):
                    asin = asin
                    url = self.review_homepage_url.format(asin)
                    # item['ASIN'] = asin
                    yield scrapy.Request(url, callback=self.page_count, meta={'asin': deepcopy(asin)})
            except Exception as e:
                print(e)
                pass

    def page_count(self, response):
        """ 获取总页数，计算总页数，构造每一页评论请求 """
        asin = response.meta['asin']
        item = {}
        item['site'] = self.site
        item['asin'] = asin
        item['url'] = self.site + '/product-reviews/{}'.format(asin)
        # with open('aaaa.html', 'w') as f:
        #     f.write(response.text)
        review_count = response.xpath('//*[contains(@class,"totalReviewCount")]//text()')
        if review_count:
            item['Review_count'] = review_count.extract_first()
        else:
            item['Review_count'] = None
        print(item['Review_count'])
        if response.xpath('//i[@data-hook="average-star-rating"]//text()'):
            item['Average_star'] = response.xpath('//i[@data-hook="average-star-rating"]//text()').extract_first()
            item['Average_star'] = re.match(r'.*?([\d.,]+).*?', item['Average_star'], re.S).group(1)
            if ',' in item['Average_star']:
                item['Average_star'] = item['Average_star'].replace(',', '.')
        else:
            item['Average_star'] = None
        if review_count:
            review_count = review_count.extract_first()
            if ',' in review_count or '.' in review_count:
                review_count = re.sub(r'[,.]', r'', review_count, re.S)
            else:
                pass
            print(review_count)
            # 计算总页数
            if 0 < int(review_count) % 10 <= 5:
                page_count = round(int(review_count) / 10) + 1
            elif int(review_count) % 10 == 0:
                page_count = int(int(review_count) / 10)
            else:
                page_count = round(int(review_count) / 10)
            print(page_count)
            if (page_count + 1) <= 500:
                for page in range(1, page_count + 1):
                    item['page'] = page
                    url = self.review_base_url.format(asin, page, page)
                    yield scrapy.Request(url, callback=self.page_review_request, meta={'item': deepcopy(item)})
            else:
                for page in range(1, 501):
                    item['page'] = page
                    url = self.review_base_url.format(asin, page, page)
                    yield scrapy.Request(url, callback=self.page_review_request, meta={'item': deepcopy(item)})
        else:
            print('对不起！没有获取你想要的信息，请重试！')

    def page_review_request(self, response):
        """ 获取评论信息 """
        item = response.meta['item']
        divs = response.xpath('//div[@data-hook="review"]')
        for div in divs:
            # 评论人物
            if div.xpath('.//span[@class="a-profile-name"]/text()'):
                item['Review_user'] = div.xpath('.//span[@class="a-profile-name"]/text()').extract_first()
            else:
                item['Review_user'] = None
            # 评论星级
            if div.xpath('.//span[@class="a-icon-alt"]/text()'):
                item['Review_star'] = div.xpath('.//span[@class="a-icon-alt"]/text()').extract_first()
                item['Review_star'] = re.match(r'.*?([\d.,]+).*?', item['Review_star'], re.S).group(1)
                if ',' in item['Review_star']:
                    item['Review_star'] = item['Review_star'].replace(',', '.')
                if float(item['Review_star']) > 3:
                    item['Review_rating'] = 'positive'
                else:
                    item['Review_rating'] = 'negative'
            else:
                item['Review_star'] = None
            # 评论时间
            if div.xpath('.//span[@data-hook="review-date"]/text()'):
                item['Review_time'] = div.xpath('.//span[@data-hook="review-date"]/text()').extract_first()
                # if ',' in item['Review_time']:
                #     item['Review_time'] = str(datetime.datetime.strptime(item['Review_time'], '%B %d, %Y')).split(' ')[0]
                # item['Review_time_month'] = '-'.join(item['Review_time'].split('-')[:-1])
            else:
                item['Review_time'] = None
                # item['Review_time_month'] = None
            # 是否购买
            if div.xpath('.//span[@data-hook="avp-badge"]/text()'):
                item['Verified_purchase'] = 'True'
            else:
                item['Verified_purchase'] = 'False'
            # 是否有VINE
            if div.xpath('.//span[@class="a-color-success a-text-bold"]'):
                item['Vine'] = 'True'
            else:
                item['Vine'] = 'False'
            # 其他信息： Product_other
            if div.xpath('.//a[@data-hook="format-strip"]/text()'):
                others = div.xpath('.//a[@data-hook="format-strip"]/text()').extract()
                # print(others)
                num = len(others)
                for i in range(2):
                    other = 'Product_other{}'.format(i + 1)
                    if i < num:
                        item[other] = others[i]
                    else:
                        item[other] = None
            else:
                for i in range(2):
                    other = 'Product_other{}'.format(i + 1)
                    item[other] = None
            # 评论标题
            if div.xpath('.//a[@data-hook="review-title"]//text()'):
                item['Review_title'] = div.xpath('.//a[@data-hook="review-title"]//text()').extract_first()
            else:
                item['Review_title'] = None
            # 评论内容
            if div.xpath('.//span[@data-hook="review-body"]//text()'):
                item['Review_content'] = ''.join(
                    [i.strip() for i in div.xpath('.//span[@data-hook="review-body"]//text()').extract()])
                if '<br>' in item['Review_content']:
                    item['Review_content'] = re.sub('<br>', '', item['Review_content'], re.S)
                else:
                    item['Review_content'] = item['Review_content']
            else:
                item['Review_content'] = None
            # 评论认可数
            if div.xpath('.//span[@data-hook="helpful-vote-statement"]/text()'):
                item['Helpful_num'] = div.xpath('.//span[@data-hook="helpful-vote-statement"]/text()').extract_first()
            else:
                item['Helpful_num'] = None
            # 回复数
            if div.xpath('.//span[contains(@class,"review-comment-total aok-hidden")]/text()'):
                item['Reply_num'] = div.xpath(
                    './/span[contains(@class,"review-comment-total aok-hidden")]/text()').extract_first()
            else:
                item['Reply_num'] = None
            # id十三位时间戳
            timestamp = int(round(time.time() * 1000))
            # 13、获取数据时间
            item['spider_time'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(timestamp / 1000))
            # print(item)
            yield item


