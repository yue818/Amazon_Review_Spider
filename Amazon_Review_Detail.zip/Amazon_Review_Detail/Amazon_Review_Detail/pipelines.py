# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
import datetime
import re


class AmazonReviewDetailPipeline(object):
    """ 数据清理 """
    de_date_dict = {
        "januar": 1,
        "februar": 2,
        "märz": 3,
        "april": 4,
        "mai": 5,
        "juni": 6,
        "juli": 7,
        "august": 8,
        "september": 9,
        "oktober": 10,
        "november": 11,
        "dezember": 12
    }
    uk_date_dict = {
        "january": 1,
        "february": 2,
        "march": 3,
        "april": 4,
        "may": 5,
        "june": 6,
        "july": 7,
        "august": 8,
        "september": 9,
        "october": 10,
        "november": 11,
        "december": 12
    }
    fr_date_dict = {
        "janvier": 1,
        "février": 2,
        "mars": 3,
        "avril": 4,
        "mai": 5,
        "juin": 6,
        "juillet": 7,
        "août": 8,
        "septembre": 9,
        "octobre": 10,
        "novembre": 11,
        "décembre": 12,
    }
    it_date_dict = {
        "gennaio": 1,
        "febbraio": 2,
        "marzo": 3,
        "aprile": 4,
        "maggio": 5,
        "giugno": 6,
        "luglio": 7,
        "agosto": 8,
        "settembre": 9,
        "ottobre": 10,
        "novembre": 11,
        "dicembre": 12,
    }
    es_date_dict = {
        "enero": 1,
        "febrero": 2,
        "marzo": 3,
        "abril": 4,
        "mayo": 5,
        "junio": 6,
        "julio": 7,
        "agosto": 8,
        "septiembre": 9,
        "octubre": 10,
        "noviembre": 11,
        "diciembre": 12,
    }
    date_dict = {
        "januar": 1,
        "februar": 2,
        "märz": 3,
        "april": 4,
        "mai": 5,
        "juni": 6,
        "juli": 7,
        "august": 8,
        "september": 9,
        "oktober": 10,
        "november": 11,
        "dezember": 12,
        "january": 1,
        "february": 2,
        "march": 3,
        "may": 5,
        "june": 6,
        "july": 7,
        "october": 10,
        "december": 12,
        "janvier": 1,
        "février": 2,
        "mars": 3,
        "avril": 4,
        "juin": 6,
        "juillet": 7,
        "août": 8,
        "septembre": 9,
        "octobre": 10,
        "novembre": 11,
        "décembre": 12,
        "gennaio": 1,
        "febbraio": 2,
        "marzo": 3,
        "aprile": 4,
        "maggio": 5,
        "giugno": 6,
        "luglio": 7,
        "agosto": 8,
        "settembre": 9,
        "ottobre": 10,
        "dicembre": 12,
        "enero": 1,
        "febrero": 2,
        "abril": 4,
        "mayo": 5,
        "junio": 6,
        "julio": 7,
        "septiembre": 9,
        "octubre": 10,
        "noviembre": 11,
        "diciembre": 12,
    }
    site_dict = {
        'com': '美国站',
        'uk': '英国站',
        'de': '德国站',
        'fr': '法国站',
        'es': '西班牙站',
        'it': '意大利站',
        'au': '澳大利亚站',
        'ca': '加拿大站',
        'mx': '墨西哥站',
    }

    def open_spider(self, spider):
        pass

    def process_item(self, item, spider):
        if spider.name == 'review_detail':
            item['site'] = item['site'].rsplit('.', 1)[-1]
            item['revie_time_web'] = item['Review_time']
            # item['site'] = self.site_dict[site]
            # if item['site'] == 'com' or item['site'] == 'ca':
            #     if ',' in item['Review_time']:
            #         item['Review_time'] = str(datetime.datetime.strptime(item['Review_time'], '%B %d, %Y')).split(' ')[0]
            # elif item['site'] == 'de':
            #     item['Review_time'] = item['Review_time'].replace('.', '').split(' ')
            #     day = item['Review_time'][0]
            #     month = self.de_date_dict[item['Review_time'][1].lower()]
            #     year = item['Review_time'][2]
            #     item['Review_time'] = year + '-' + str(month) + '-' + day
            # elif item['site'] == 'uk' or item['site'] == 'au':
            #     item['Review_time'] = item['Review_time'].replace('.', '').split(' ')
            #     day = item['Review_time'][0]
            #     month = self.uk_date_dict[item['Review_time'][1].lower()]
            #     year = item['Review_time'][2]
            #     item['Review_time'] = year + '-' + str(month) + '-' + day
            # elif item['site'] == 'fr':
            #     item['Review_time'] = item['Review_time'].replace('.', '').split(' ')
            #     day = item['Review_time'][0]
            #     month = self.fr_date_dict[item['Review_time'][1].lower()]
            #     year = item['Review_time'][2]
            #     item['Review_time'] = year + '-' + str(month) + '-' + day
            # elif item['site'] == 'it':
            #     item['Review_time'] = item['Review_time'].replace('.', '').split(' ')
            #     day = item['Review_time'][0]
            #     month = self.it_date_dict[item['Review_time'][1].lower()]
            #     year = item['Review_time'][2]
            #     item['Review_time'] = year + '-' + str(month) + '-' + day
            # elif item['site'] == 'es' or item['site'] == 'mx':
            #     item['Review_time'] = item['Review_time'].replace('.', '').split(' ')
            #     day = item['Review_time'][0]
            #     month = self.es_date_dict[item['Review_time'][2].lower()]
            #     year = item['Review_time'][4]
            #     item['Review_time'] = year + '-' + str(month) + '-' + day

            # if spider.name == 'review_detail':
            # item['site'] = item['site'].rsplit('.', 1)[-1]
            if item['site'] == 'com' or item['site'] == 'ca':  # 美国和加拿大的日期格式是月 日 年
                item['Review_time'] = item['Review_time'].replace(',', '').split(' ')
                day = item['Review_time'][1]
                month = self.date_dict[item['Review_time'][0].lower()]
                year = item['Review_time'][2]
                item['Review_time'] = year + '-' + str(month) + '-' + day
            elif item['site'] == 'es' or item['site'] == 'mx':  # 西班牙和墨西哥的日期中需要去掉de 字符串
                item['Review_time'] = item['Review_time'].replace('.', '').split(' ')
                day = item['Review_time'][0]
                month = self.date_dict[item['Review_time'][2].lower()]
                year = item['Review_time'][4]
                item['Review_time'] = year + '-' + str(month) + '-' + day
            else:
                item['Review_time'] = item['Review_time'].replace('.', '').split(' ')
                day = item['Review_time'][0]
                month = self.date_dict[item['Review_time'][1].lower()]
                year = item['Review_time'][2]
                item['Review_time'] = year + '-' + str(month) + '-' + day

        print(item)
        return item

    def close_spider(self, spider):
        """ 制作数据透视表 """
        pass


